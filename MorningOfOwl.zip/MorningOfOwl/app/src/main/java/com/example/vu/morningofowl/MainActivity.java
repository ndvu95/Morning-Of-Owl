package com.example.vu.morningofowl;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.vu.morningofowl.adapter.Phim_Adapter;
import com.example.vu.morningofowl.model.Phim;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private ListView lvPhim;
    private ArrayList<Phim> arrayList;
    private Phim_Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        lvPhim = (ListView)findViewById(R.id.lvPhim);
        arrayList = new ArrayList<>();
        adapter = new Phim_Adapter(MainActivity.this, R.layout.dong_layout,arrayList);
        lvPhim.setAdapter(adapter);


       arrayList.add(new Phim("Princess Mononoke","https://moowlcom.000webhostapp.com/layout_design_android_blog.mp4","https://c2.staticflickr.com/2/1865/42471550050_cdea85be44_o.jpg","Hoạt Hình","Matsuda Yōji","21548 Lượt Xem", 3.5f));
       arrayList.add(new Phim("The Last Airbender","","https://c2.staticflickr.com/2/1873/44280252771_1813bb322c_o.jpg","Hoạt Hình","Noah Ringer","35165 Lượt Xem", 3.5f));
       arrayList.add(new Phim("Back To The Jurassic","","https://c2.staticflickr.com/2/1870/42472021840_4cc133e217_o.jpg","Hoạt Hình","Melanie Griffith","15846 Lượt Xem", 3.5f));
       arrayList.add(new Phim("Minions","","https://c2.staticflickr.com/2/1884/43374535035_452843dddd_n.jpg","Hoạt Hình","","21548 Lượt Xem", 3.5f));
       arrayList.add(new Phim("Sing","","https://c2.staticflickr.com/2/1845/44231813242_62e9bc45e8_n.jpg","Hoạt Hình","","39842 Lượt Xem", 3.5f));

        adapter.notifyDataSetChanged();


        lvPhim.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               final Phim phim = arrayList.get(position);
                Intent manhinhDetail = new Intent(MainActivity.this, DetailActivity.class);
                for(int i=0; i< arrayList.size(); i++){
                    manhinhDetail.putExtra("dulieu", (Serializable)phim);
                }
                startActivity(manhinhDetail);
            }
        });
    }
//    private void fakeData() {
//        //Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.princess_mononoke);
//        for (int i = 0; i < 2; i++) {
//            Phim p= new Phim("Princess Mononoke","","https://c2.staticflickr.com/2/1889/30409125548_babd086b2c_o.jpg","Hoạt Hình","","21548 Lượt Xem", 3.5f);
//
//            arrayList.add(p);
//        }
//        //lưu ý: bất kì khi nào thay đổi mảng thì sẽ phải cập nhật lại giao diện
//        adapter.notifyDataSetChanged();
//    }
}
